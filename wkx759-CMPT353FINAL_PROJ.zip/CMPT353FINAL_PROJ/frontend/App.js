import React, { useState, useEffect, useCallback } from "react";
import { BrowserRouter as Router, Routes, Route, Link, Navigate } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import { useLocation } from "react-router-dom";
import axios from "axios";
import LoginPage from "./LoginPage";
import RegisterPage from "./RegisterPage";
import "./App.css";

function App() {
    const [user, setUser] = useState(null);
// if token is there, then they are a user of the site 
    useEffect(() => {
        const token = localStorage.getItem("token");
        if (token) {
            setUser(true); // Assume user is logged in if token exists
        }
    }, []);

// once a user logs out, remove their token 
    const handleLogout = () => {
        localStorage.removeItem("token");
        setUser(null);
    };
// navbar shows certain feactues if you are logged in or not
    return (
        <Router>
            <div className="app">
                <nav className="navbar">
                    <Link to="/" className="nav-link">Home</Link>
                    <Link to="/channels" className={`nav-link ${user ? "" : "disabled"}`}>Channels</Link>
                    <Link to="/search" className={`nav-link ${user ? "" : "disabled"}`}>Search</Link>
                    
                    {user ? (
                        <button onClick={handleLogout} className="nav-link logout-button">Logout</button>
                    ) : (
                        <>
                            <Link to="/login" className="nav-link">Login</Link>
                            <Link to="/register" className="nav-link">Register</Link>
                        </>
                    )}
                </nav>

                <Routes>
                    <Route path="/" element={<LandingPage />} />
                    <Route path="/login" element={<LoginPage setUser={setUser} />} />
                    <Route path="/register" element={<RegisterPage />} />
                    <Route path="/channels" element={user ? <ChannelsPage /> : <Navigate to="/login" />} />
                    <Route path="/search" element={user ? <SearchPage /> : <Navigate to="/login" />} />
                </Routes>
            </div>
        </Router>
    );
}
// original landing page, will show for users and non-users
function LandingPage() {
    return (
        <div className="landing">
            <h1>Welcome to the Programming Issues Tool</h1>
            <p>Post questions, provide answers, and collaborate with others!</p>
            <p>Click on the Channels tab to post to a channel</p>
            <p>Click on the Search tab to search for a specific topic</p>
            <p>If those tabs are greyed out, either register or log in!</p>
        </div>
    );
}
// searchpage
function SearchPage() {
    const [searchQuery, setSearchQuery] = useState("");
    const [searchResults, setSearchResults] = useState([]);
    const navigate = useNavigate();

    const handleSearch = async () => {
        if (!searchQuery) return;
        try {
            const response = await axios.get(`http://localhost:5000/search/posts?query=${searchQuery}`);
            setSearchResults(response.data);
        } catch (error) {
            console.error("Error searching posts:", error);
        }
    };
// extra feature, go to post 
    const goToPost = (channelId) => {
        navigate(`/channels`, { state: { channelId } });
    };

    return (
        <div className="search">
            <h1>Search Posts</h1>
            <input
                type="text"
                placeholder="Search for posts"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
            />
            <button
                onClick={handleSearch}
                className="create-channel-button" //not actually to create a channel, just for style 
            >  
                Search 
            </button>

            <div className="search-results">
                {searchResults.map((post) => (
                    <div key={post._id} className="search-result">
                        <p>{post.content}</p>
                        <small>Posted by {post.author}</small>
                        <button onClick={() => goToPost(post.channelId)}>View Post</button>
                    </div>
                ))}
            </div>
        </div>
    );
}
// channels page
function ChannelsPage() {
    const [channels, setChannels] = useState([]);
    const [newChannelName, setNewChannelName] = useState("");
    const [selectedChannel, setSelectedChannel] = useState(null);
    const [posts, setPosts] = useState([]);
    // using location to save a channelID for the posts
    const location = useLocation();
    const localuser = localStorage.getItem("user")

    const fetchChannels = useCallback(async () => {
        try {
            const response = await axios.get("http://localhost:5000/channels");
            console.log("Fetched channels:", response.data);
            setChannels(response.data);
        
            const channelIdFromSearch = location.state?.channelId;
            if (channelIdFromSearch) {
                const foundChannel = response.data.find(ch => ch._id === channelIdFromSearch);
                if (foundChannel) {
                    setSelectedChannel(foundChannel);
                    fetchPosts(foundChannel._id);
                }
            } 
        } catch (error) {
            console.error("Error fetching channels:", error);
        }
    },[location.state]);

    useEffect(() => {
        fetchChannels();
    }, [fetchChannels]);

    const createChannel = async () => {
        try {
            const response = await axios.post("http://localhost:5000/create-channel", {
                name: newChannelName,
            });
            console.log("Channel created:", response.data);
            fetchChannels();
            setNewChannelName("");
        } catch (error) {
            console.error("Error creating channel:", error);
        }
    };

    const selectChannel = (channel) => {
        setSelectedChannel(channel);
        fetchPosts(channel._id);
    };
// fetching posts for each channel 
    const fetchPosts = async (channelId) => {
        console.log("Fetching posts for channel:", channelId);
        try {
            const response = await axios.get(`http://localhost:5000/channels/${channelId}/posts`);
            console.log("Fetched posts:", response.data);
            setPosts(response.data);
        } catch (error) {
            console.error("Error fetching posts:", error);
        }
    };

    return (
        <div className="channels">
            <h1>Channels</h1>
            <div className="channel-list">
                {channels.map((channel) => (
                    <button
                        key={channel._id}
                        id={`channel-${channel._id}`}
                        onClick={() => selectChannel(channel)}
                        className="channel-button"
                    >
                        {channel.name}
                    </button>
                ))}
            </div>
            <input
                type="text"
                placeholder="New channel name"
                value={newChannelName}
                onChange={(e) => setNewChannelName(e.target.value)}
            />
            <button onClick={createChannel} className="create-channel-button">
                Create Channel
            </button>

            {selectedChannel && (
                <MessagesPage
                    channel={selectedChannel}
                    posts={posts}
                    refreshPosts={() => fetchPosts(selectedChannel._id)}
                    user={localuser}
                />
            )}
        </div>
    );
}
// for message page
function MessagesPage({ channel, posts, refreshPosts,user }) {
    const [newMessage, setNewMessage] = useState("");
    const [responses, setResponses] = useState({}); // stores the repsones per post
    const localuser = localStorage.getItem("user")

    const postMessage = async () => {
        if (!channel || !channel._id) {
            console.error("Channel ID is missing");
            return;
        }

        try {
            await axios.post(`http://localhost:5000/channels/${channel._id}/posts`, {
                userId: localuser,
                content: newMessage,
            });
            setNewMessage("");
            refreshPosts();
        } catch (error) {
            console.error("Error posting message:", error);
        }
    };
    const postResponse = async (postId) => {
        if (!responses[postId]) {
            console.error("Response cannot be empty");
            return;
        }

        try {
            await axios.post(`http://localhost:5000/posts/${postId}/responses`, {
                userId: localuser, 
                content: responses[postId],
            });
            setResponses("");  
            refreshPosts();
        } catch (error) {
            console.error("Error posting response:", error);
        }
    };

    return (
        <div className="messages">
            <h2>{channel?.name}</h2>
            <div className="message-list">
                {posts.map((post, index) => (
                    <div key={index} className="message">
                        <p>{post.content}</p>
                        <small>Posted by {post.author} at {post.timestamp}</small>

                        {/* Display responses */}
                        <div className="response-list">
                            {post.responses?.map((response, idx) => (
                                <div key={idx} className="response">
                                    <p>{response.content}</p>
                                    <small>Responded by {response.author}</small>
                                </div>
                            ))}
                        </div>

                        {/* Input and button to add a response */}
                        <input
                            type="text"
                            placeholder="Write a response"
                            value={responses[post._id] || ""} // Ensure each post has its own response state
                            onChange={(e) => setResponses({ ...responses, [post._id]: e.target.value })}
                        />
                        <button onClick={() => postResponse(post._id)} className="post-response-button">
                            Post Response
                        </button>
                    </div>
                ))}
            </div>

            {/* Input and button to create a new message */}
            <input
                type="text"
                placeholder="Write a message"
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
            />
            <button onClick={postMessage} className="post-message-button">
                Post Message
            </button>
        </div>
    );
}

export default App;

