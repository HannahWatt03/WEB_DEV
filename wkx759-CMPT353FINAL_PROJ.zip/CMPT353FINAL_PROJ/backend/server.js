const express = require("express");
const cors = require("cors");
const Nano = require("nano");

const app = express();
app.use(cors());
app.use(express.json());

const couchDbUrl = process.env.COUCHDB_URL || "http://admin:password@couchdb1:5984";
const nano = Nano(couchDbUrl);



const channelsDb = nano.db.use("channels");
const postsDb = nano.db.use("posts");
const userDb = nano.db.use("users");

// using jwt to create a token, secret key is not so secret
const jwt = require("jsonwebtoken");
const secretKey = "your_secret_key";

// for token creation for the site
const authenticateToken = (req, res, next) => {
    const token = jwt.sign({ userId: user._id, email: user.email }, "your_secret_keyt", { expiresIn: "1h" });

    if (!token) return res.status(401).json({ error: "No token provided" });

    console.log("Token:", token); // Log the token

   // When verifying the token (in authenticateToken)
    jwt.verify(token, "your_secret_key", (err, user) => {
    if (err) return res.sendStatus(403);  // Token verification failed
    req.user = user;
    next();
    });
};
(async () => {
    try {
        await postsDb.createIndex({
            index: { fields: ["channel_id"] }
        });
        console.log("Index on 'channel_id' created.");
    } catch (error) {
        console.error("Error creating index:", error);
    }
})();

// creating a user
app.post("/register", async (req, res) => {
    const { email, password } = req.body;
    if (!email || !password) {
        return res.status(400).json({ error: "Email and password are required" });
    }

    try {
        const newUser = { email, password }; // You should hash the password before saving
        const response = await userDb.insert(newUser);
        res.status(201).json({ message: "User registered", id: response.id });
    } catch (error) {
        console.error("Error registering user:", error);
        res.status(500).json({ error: "Failed to register user" });
    }
});
// logging in 
app.post("/login", async (req, res) => {
    const { email, password } = req.body;
    
    if (!email || !password) {
        return res.status(400).json({ error: "Email and password are required" });
    }

    try {
        // Find the user in CouchDB
        const response = await userDb.find({
            selector: { email }
        });

        if (response.docs.length === 0) {
            return res.status(401).json({ error: "Invalid email or password" });
        }

        const user = response.docs[0];

        // Password check (currently plain text, should hash in production)
        if (user.password !== password) {
            return res.status(401).json({ error: "Invalid email or password" });
        }

        // Generate JWT token
        const token = jwt.sign({ userId: user._id, email: user.email }, secretKey, { expiresIn: "1h" });

        res.json({ message: "Login successful", token });
    } catch (error) {
        console.error("Error logging in:", error);
        res.status(500).json({ error: "Login failed" });
    }
});

// Fetch all channels
app.get("/channels", async (req, res) => {
    try {
        const response = await channelsDb.list({ include_docs: true });
        const channels = response.rows.map(row => row.doc);
        res.json(channels);
    } catch (error) {
        console.error("Error fetching channels:", error);
        res.status(500).json({ error: "Failed to fetch channels" });
    }
});

// Create a new channel
app.post("/create-channel", async (req, res) => {
    const { name } = req.body;
    if (!name) return res.status(400).json({ error: "Channel name is required" });

    try {
        const newChannel = { name, type: "channel" };
        const response = await channelsDb.insert(newChannel);
        res.status(201).json({ message: "Channel created", id: response.id });
    } catch (error) {
        console.error("Error creating channel:", error);
        res.status(500).json({ error: "Failed to create channel" });
    }
});

// Fetch posts for a specific channel
app.get("/channels/:id/posts", async (req, res) => {
    const { id } = req.params;
    console.log(`Fetching posts for channel ID: ${id}`);

    try {
        const response = await postsDb.find({
            selector: {
                $or: [
                    { channel_id: id },
                    { channelId: id }
                ]
            }
        });
        console.log("Fetched posts:", response.docs);
        res.json(response.docs);
    } catch (error) {
        console.error("Error fetching posts:", error);
        res.status(500).json({ error: "Failed to fetch posts" });
    }
});


// Post a new message in a channel
app.post("/channels/:id/posts", async (req, res) => {
    const { id } = req.params;
    const { userId, content } = req.body;

    if (!userId || !content) {
        return res.status(400).json({ error: "User ID and content are required" });
    }

    try {
        const newPost = {
            channelId: id,
            author: userId,
            content,
            timestamp: new Date().toISOString(),
            responses: []
        };

        const response = await postsDb.insert(newPost);
        res.status(201).json({ message: "Post created", postId: response.id });
    } catch (error) {
        console.error("Error creating post:", error);
        res.status(500).json({ error: "Failed to create post" });
    }
});

app.post("/posts/:postId/responses", async (req, res) => {
    const { postId } = req.params;
    const { userId, content } = req.body;

    if (!userId || !content) {
        return res.status(400).json({ error: "User ID and content are required." });
    }

    try {
        // Fetch the post from CouchDB
        const post = await postsDb.get(postId);
        if (!post.responses) {
            post.responses = []; // Ensure responses array exists
        }

        // Add new response
        post.responses.push({
            userId,
            content,
            timestamp: new Date().toISOString(),
        });

        // Save updated post
        await postsDb.insert(post);
        res.status(200).json({ message: "Response added successfully!" });
    } catch (error) {
        console.error("Error adding response:", error);
        res.status(500).json({ error: "Failed to add response." });
    }
});
app.get("/search/posts", async (req, res) => {
    const { query } = req.query;
    if (!query) {
        return res.status(400).json({ error: "Search query is required" });
    }

    try {
        const response = await postsDb.find({
            selector: {
                content: { $regex: `(?i)${query}` } // Case-insensitive search
            }
        });
        res.json(response.docs);
    } catch (error) {
        console.error("Error searching posts:", error);
        res.status(500).json({ error: "Failed to search posts" });
    }
});

// to ensure the user that is currently logged is on their own account
app.get("/me", authenticateToken, async (req, res) => {
    try {
        const userId = req.user.id;  // Check if req.user is undefined
        if (!userId) return res.status(401).json({ error: "Unauthorized" });

        const user = await db.get(userId); // Make sure db.get() is working
        res.json(user);
    } catch (error) {
        console.error("Error in /me:", error);
        res.status(500).json({ error: "Internal Server Error" });
    }
});

// for running backend 
app.listen(5000, '0.0.0.0', () => {
    console.log("Server running on http://localhost:5000");
});

